#ifndef _TJU_TCP_H_
#define _TJU_TCP_H_

#include "global.h"
#include "tju_packet.h"
#include "kernel.h"


/*
创建 TCP socket 
初始化对应的结构体
设置初始状态为 CLOSED
*/
tju_tcp_t* tju_socket();

/*
绑定监听的地址 包括ip和端口
*/
int tju_bind(tju_tcp_t* sock, tju_sock_addr bind_addr);

/*
被动打开 监听bind的地址和端口
设置socket的状态为LISTEN
*/
int tju_listen(tju_tcp_t* sock);

/*
接受连接 
返回与客户端通信用的socket
这里返回的socket一定是已经完成3次握手建立了连接的socket
因为只要该函数返回, 用户就可以马上使用该socket进行send和recv
*/
tju_tcp_t* tju_accept(tju_tcp_t* sock);


/*
连接到服务端
该函数以一个socket为参数
调用函数前, 该socket还未建立连接
函数正常返回后, 该socket一定是已经完成了3次握手, 建立了连接
因为只要该函数返回, 用户就可以马上使用该socket进行send和recv
*/
int tju_connect(tju_tcp_t* sock, tju_sock_addr target_addr);


int tju_send (tju_tcp_t* sock, const void *buffer, int len);
int tju_recv (tju_tcp_t* sock, void *buffer, int len);

/*
关闭一个TCP连接
这里涉及到四次挥手
*/
int tju_close (tju_tcp_t* sock);
int tju_handle_packet(tju_tcp_t* sock, char* pkt);
void handle_syn(tju_tcp_t* listen_socks,char* pkt);
void timer_2msl(tju_tcp_t* sock);
void* msl_timer_thread(void* arg);
void free_socket_resources(tju_tcp_t* sock);
uint16_t random_port();
void* tju_close_thread(void* arg);
void Timeout_retransmission(tju_tcp_t* sock, int exp_state, char* pkt, int pktlen);
void* send_pkt_thread(void* arg);
void* resend_pkt_thread(void* arg);
void check_pkt_timeout(tju_tcp_t* sock);
void check_cached_pkt(tju_tcp_t* sock);
void my_swap(char** a,char** b);
int cache_pkt(tju_tcp_t* sock,uint32_t seq_num,char* data,int data_len);
sr_packet_t* find_pkt_rtt(sender_window_t* send_win,uint32_t ack_num);
void update_RTO(rtt_stats_t* rtt,long samplertt_us);
void handle_timeout_pkt(tju_tcp_t* sock,sr_packet_t* packet,struct timeval nowtime);
void handle_fast_retransmit(tju_tcp_t* sock);
//void send_tcp_flags(tju_tcp_t* sock, uint8_t flags, uint32_t seq,uint32_t ack) ;                     
#endif

